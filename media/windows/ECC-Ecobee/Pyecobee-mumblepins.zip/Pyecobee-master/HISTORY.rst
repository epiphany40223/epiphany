.. :changelog:

Release History
---------------

1.2.1 (2017-06-01)
++++++++++++++++++

* Internal __slots__ improvements

1.2.0 (2017-05-31)
++++++++++++++++++

* Internal refactoring of EcobeeObject and EcobeeResponse


1.1.1 (2017-05-31)
++++++++++++++++++

* Miscellaneous minor internal changes to facilitate the automatic generation of PlantUML Class Diagrams


1.1.0 (2017-05-24)
++++++++++++++++++

* Added ecobee API operations that are only accessible by EMS and Utility accounts


1.0.0 (2017-05-12)
++++++++++++++++++

* First public release supporting all ecobee API operations except those that are only accessible by EMS and Utility accounts
